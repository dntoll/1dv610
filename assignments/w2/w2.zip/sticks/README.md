# The game of the last stick

## Rules
Game starts with 22 sticks
The one who draws the last stick looses.
A player must draw 1,2 or 3 sticks.

## Implementation

![Class diagram][https://yuml.me/f7c8fcc9.png]

The current implementation uses session for persistent storage of game state.